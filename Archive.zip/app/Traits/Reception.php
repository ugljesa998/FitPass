<?php
namespace App\Traits;

use App\Models\Card;
use App\Models\GymObject;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Reception as ReceptionModel;

trait Reception
{
    /**
     * @param $params
     * @return array
     */
    public function getUserReception($params): array
    {
        $ret = [
            'message'     => '',
            'data'        => [],
            'status_code' => Response::HTTP_OK,
        ];

        $card = Card::where('id', $params['card_uuid'])->first();
        $object = GymObject::where('id', $params['object_uuid'])->first();

        if(empty($card) || empty($object)){
            $ret['status_code'] = Response::HTTP_UNAUTHORIZED;
            $ret['message'] = 'Nijem moguće prijaviti se, podaci za prijavu nisu validni!';
            return $ret;
        }

        $userEntry = $this->checkUserEntry($params);

        if(!empty($userEntry)){
            $ret['status_code'] = Response::HTTP_UNAUTHORIZED;
            $ret['message'] = 'Dostigli ste maksimalan broj prijava u jednom danu, novu prijavu možete izvršiti sledećeg dana!';
            return $ret;
        }

        $reception = ReceptionModel::create([
            'object_id' => $params['object_uuid'],
            'card_id' => $params['card_uuid'],
        ]);

        $user = Card::find($reception['card_id'])->user;
        $object = GymObject::find($reception['object_id']);

        $ret['data'] = [
            'object_name' => $object['name'],
            'first_name' => $user['first_name'],
            'last_name' => $user['last_name'],

        ];
        $ret['message'] = 'Uspešno ste se prijavili.';
        $ret['status'] = 'OK';

        return $ret;
    }

    public function checkUserEntry($params)
    {
        $ret = [];

        $reception = new ReceptionModel;

        $query = DB::table($reception->table . ' as r')
            ->select([
                'r.card_id'
            ])
            ->where('r.card_id', $params['card_uuid'])
            ->where('r.entry_date', Carbon::now()->toDateString())
        ;

        $ret = json_decode(json_encode($query->get()), true);

        return $ret;
    }
}
