<?php

namespace App\Http\Controllers;

use App\Models\Card;
use App\Models\GymObject;
use App\Models\Reception;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response as HTTP;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\ReceptionRequest;

class FunctionController extends Controller
{

    public function entryUser(ReceptionRequest $request)
    {
        $ret = [
            'data' => [],
            'status_code' => HTTP::HTTP_OK,
            'message' => ''
        ];

        $params = $request->only(['object_uuid', 'card_uuid']);

        $card = Card::where('id', $params['card_uuid'])->first();
        $object = GymObject::where('id', $params['object_uuid'])->first();

        if(empty($card) || empty($object)){
            $ret['status_code'] = HTTP::HTTP_UNAUTHORIZED;
            $ret['message'] = 'Nije moguce pristupiti ovom objektu';
            return Response::json($ret)->setStatusCode($ret['status_code']);
        }

        $test = $this->checkUserEntry($params);

        if(!empty($test)){
            return 'VEC SI BI';
        }

        $reception = new Reception;

        $reception->object_id = $params['object_uuid'];
        $reception->card_id = $params['card_uuid'];

        $reception->save();



            return Response::json($ret)->setStatusCode($ret['status_code']);

    }

    public function checkUserEntry($params)
    {
        $ret = [];

        $reception = new Reception;
        $query = DB::table($reception->table . ' as r')
            ->select([
                'r.card_id'
            ])
            ->where('r.card_id', $params['card_uuid'])
            ->where('r.entry_date', Carbon::now()->toDateString())
        ;

        $rawData = json_decode(json_encode($query->get()), true);

        return $rawData;
    }

}
