<?php

namespace App\Classes;

use App\Interface\ReceptionInterface;
use App\Traits\Reception;

class ReceptionUsers implements ReceptionInterface
{
    use Reception;
}
